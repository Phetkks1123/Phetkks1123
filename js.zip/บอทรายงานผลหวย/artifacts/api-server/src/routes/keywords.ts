import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { botSettingsTable } from "@workspace/db/schema";
import {
  GetKeywordsResponse,
  SetKeywordParams,
  SetKeywordBody,
  SetKeywordResponse,
  DeleteKeywordParams,
  DeleteKeywordResponse,
  ClearKeywordsResponse,
} from "@workspace/api-zod";
import { sql } from "drizzle-orm";

const router: IRouter = Router();

async function ensureSettings() {
  await db
    .insert(botSettingsTable)
    .values({ id: "singleton" })
    .onConflictDoNothing();
}

async function getKeywords(): Promise<Record<string, string>> {
  const [row] = await db.select({ keywords: botSettingsTable.keywords }).from(botSettingsTable).limit(1);
  if (!row) return {};
  return (row.keywords as Record<string, string>) ?? {};
}

router.get("/", async (_req, res) => {
  await ensureSettings();
  const keywords = await getKeywords();
  res.json(GetKeywordsResponse.parse({ keywords }));
});

router.put("/:keyword", async (req, res) => {
  const { keyword } = SetKeywordParams.parse(req.params);
  const { reply } = SetKeywordBody.parse(req.body);
  await ensureSettings();
  const current = await getKeywords();
  const updated = { ...current, [keyword]: reply };
  await db.update(botSettingsTable).set({ keywords: sql`${JSON.stringify(updated)}::jsonb` });
  res.json(SetKeywordResponse.parse({ success: true, message: `Keyword "${keyword}" set` }));
});

router.delete("/:keyword", async (req, res) => {
  const { keyword } = DeleteKeywordParams.parse(req.params);
  await ensureSettings();
  const current = await getKeywords();
  const updated = { ...current };
  delete updated[keyword];
  await db.update(botSettingsTable).set({ keywords: sql`${JSON.stringify(updated)}::jsonb` });
  res.json(DeleteKeywordResponse.parse({ success: true, message: `Keyword "${keyword}" deleted` }));
});

router.delete("/", async (_req, res) => {
  await ensureSettings();
  await db.update(botSettingsTable).set({ keywords: sql`'{}'::jsonb` });
  res.json(ClearKeywordsResponse.parse({ success: true, message: "All keywords cleared" }));
});

export default router;
