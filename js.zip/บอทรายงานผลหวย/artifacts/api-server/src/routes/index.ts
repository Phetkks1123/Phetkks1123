import { Router, type IRouter } from "express";
import healthRouter from "./health";
import settingsRouter from "./settings";
import blacklistRouter from "./blacklist";
import keywordsRouter from "./keywords";
import imageKeywordsRouter from "./image-keywords";
import commandsRouter from "./commands";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/settings", settingsRouter);
router.use("/blacklist", blacklistRouter);
router.use("/keywords", keywordsRouter);
router.use("/image-keywords", imageKeywordsRouter);
router.use("/commands", commandsRouter);

export default router;
