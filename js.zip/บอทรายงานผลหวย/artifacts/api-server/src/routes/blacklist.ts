import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { botSettingsTable } from "@workspace/db/schema";
import {
  GetBlacklistResponse,
  AddToBlacklistParams,
  AddToBlacklistResponse,
  RemoveFromBlacklistParams,
  RemoveFromBlacklistResponse,
  ClearBlacklistResponse,
} from "@workspace/api-zod";
import { sql } from "drizzle-orm";

const router: IRouter = Router();

async function ensureSettings() {
  await db
    .insert(botSettingsTable)
    .values({ id: "singleton" })
    .onConflictDoNothing();
}

async function getBlacklist(): Promise<string[]> {
  const [row] = await db.select({ blacklist: botSettingsTable.blacklist }).from(botSettingsTable).limit(1);
  if (!row) return [];
  return (row.blacklist as string[]) ?? [];
}

router.get("/", async (_req, res) => {
  await ensureSettings();
  const blacklist = await getBlacklist();
  res.json(GetBlacklistResponse.parse({ blacklist }));
});

router.post("/:mid", async (req, res) => {
  const { mid } = AddToBlacklistParams.parse(req.params);
  await ensureSettings();
  const current = await getBlacklist();
  if (!current.includes(mid)) {
    const updated = [...current, mid];
    await db.update(botSettingsTable).set({ blacklist: sql`${JSON.stringify(updated)}::jsonb` });
  }
  res.json(AddToBlacklistResponse.parse({ success: true, message: `Added ${mid} to blacklist` }));
});

router.delete("/:mid", async (req, res) => {
  const { mid } = RemoveFromBlacklistParams.parse(req.params);
  await ensureSettings();
  const current = await getBlacklist();
  const updated = current.filter((m) => m !== mid);
  await db.update(botSettingsTable).set({ blacklist: sql`${JSON.stringify(updated)}::jsonb` });
  res.json(RemoveFromBlacklistResponse.parse({ success: true, message: `Removed ${mid} from blacklist` }));
});

router.delete("/", async (_req, res) => {
  await ensureSettings();
  await db.update(botSettingsTable).set({ blacklist: sql`'[]'::jsonb` });
  res.json(ClearBlacklistResponse.parse({ success: true, message: "Blacklist cleared" }));
});

export default router;
