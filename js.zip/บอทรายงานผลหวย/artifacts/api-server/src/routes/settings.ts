import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { botSettingsTable } from "@workspace/db/schema";
import {
  GetSettingsResponse,
  UpdateSettingsBody,
  UpdateSettingsResponse,
  SetAddMessageBody,
  SetAddMessageResponse,
  SetMentionMessageBody,
  SetMentionMessageResponse,
  SetWelcomeMessageBody,
  SetWelcomeMessageResponse,
} from "@workspace/api-zod";

const router: IRouter = Router();

async function getOrCreateSettings() {
  await db
    .insert(botSettingsTable)
    .values({ id: "singleton" })
    .onConflictDoNothing();
  const [row] = await db.select().from(botSettingsTable).limit(1);
  return row;
}

router.get("/", async (_req, res) => {
  const settings = await getOrCreateSettings();
  const data = GetSettingsResponse.parse({
    auto_block: settings.auto_block,
    auto_read: settings.auto_read,
    auto_join: settings.auto_join,
    auto_jointicket: settings.auto_jointicket,
    auto_leave: settings.auto_leave,
    auto_add: settings.auto_add,
    auto_mention: settings.auto_mention,
    auto_welcome: settings.auto_welcome,
    add_message: settings.add_message,
    mention_message: settings.mention_message,
    welcome_message: settings.welcome_message,
  });
  res.json(data);
});

router.patch("/", async (req, res) => {
  const body = UpdateSettingsBody.parse(req.body);
  await getOrCreateSettings();
  const [updated] = await db
    .update(botSettingsTable)
    .set({ ...body })
    .returning();
  const data = UpdateSettingsResponse.parse({
    auto_block: updated.auto_block,
    auto_read: updated.auto_read,
    auto_join: updated.auto_join,
    auto_jointicket: updated.auto_jointicket,
    auto_leave: updated.auto_leave,
    auto_add: updated.auto_add,
    auto_mention: updated.auto_mention,
    auto_welcome: updated.auto_welcome,
    add_message: updated.add_message,
    mention_message: updated.mention_message,
    welcome_message: updated.welcome_message,
  });
  res.json(data);
});

router.put("/add-message", async (req, res) => {
  const body = SetAddMessageBody.parse(req.body);
  await getOrCreateSettings();
  await db.update(botSettingsTable).set({ add_message: body.message });
  const data = SetAddMessageResponse.parse({ success: true, message: "Add message updated" });
  res.json(data);
});

router.put("/mention-message", async (req, res) => {
  const body = SetMentionMessageBody.parse(req.body);
  await getOrCreateSettings();
  await db.update(botSettingsTable).set({ mention_message: body.message });
  const data = SetMentionMessageResponse.parse({ success: true, message: "Mention message updated" });
  res.json(data);
});

router.put("/welcome-message", async (req, res) => {
  const body = SetWelcomeMessageBody.parse(req.body);
  await getOrCreateSettings();
  await db.update(botSettingsTable).set({ welcome_message: body.message });
  const data = SetWelcomeMessageResponse.parse({ success: true, message: "Welcome message updated" });
  res.json(data);
});

export default router;
