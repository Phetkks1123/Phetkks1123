import { Router, type IRouter } from "express";
import { db } from "@workspace/db";
import { botSettingsTable } from "@workspace/db/schema";
import {
  GetImageKeywordsResponse,
  SetImageKeywordParams,
  SetImageKeywordBody,
  SetImageKeywordResponse,
  DeleteImageKeywordParams,
  DeleteImageKeywordResponse,
  ClearImageKeywordsResponse,
} from "@workspace/api-zod";
import { sql } from "drizzle-orm";

const router: IRouter = Router();

async function ensureSettings() {
  await db
    .insert(botSettingsTable)
    .values({ id: "singleton" })
    .onConflictDoNothing();
}

async function getImageKeywords(): Promise<Record<string, string>> {
  const [row] = await db.select({ image_keywords: botSettingsTable.image_keywords }).from(botSettingsTable).limit(1);
  if (!row) return {};
  return (row.image_keywords as Record<string, string>) ?? {};
}

router.get("/", async (_req, res) => {
  await ensureSettings();
  const imageKeywords = await getImageKeywords();
  res.json(GetImageKeywordsResponse.parse({ imageKeywords }));
});

router.put("/:keyword", async (req, res) => {
  const { keyword } = SetImageKeywordParams.parse(req.params);
  const { imagePath } = SetImageKeywordBody.parse(req.body);
  await ensureSettings();
  const current = await getImageKeywords();
  const updated = { ...current, [keyword]: imagePath };
  await db.update(botSettingsTable).set({ image_keywords: sql`${JSON.stringify(updated)}::jsonb` });
  res.json(SetImageKeywordResponse.parse({ success: true, message: `Image keyword "${keyword}" set` }));
});

router.delete("/:keyword", async (req, res) => {
  const { keyword } = DeleteImageKeywordParams.parse(req.params);
  await ensureSettings();
  const current = await getImageKeywords();
  const updated = { ...current };
  delete updated[keyword];
  await db.update(botSettingsTable).set({ image_keywords: sql`${JSON.stringify(updated)}::jsonb` });
  res.json(DeleteImageKeywordResponse.parse({ success: true, message: `Image keyword "${keyword}" deleted` }));
});

router.delete("/", async (_req, res) => {
  await ensureSettings();
  await db.update(botSettingsTable).set({ image_keywords: sql`'{}'::jsonb` });
  res.json(ClearImageKeywordsResponse.parse({ success: true, message: "All image keywords cleared" }));
});

export default router;
