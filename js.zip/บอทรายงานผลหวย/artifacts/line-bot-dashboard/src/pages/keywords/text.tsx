import { PageHeader } from "@/components/page-header";
import { Card, CardContent, Button, Input, Label, Badge } from "@/components/ui/core";
import { useGetKeywords, useSetKeyword, useDeleteKeyword, useClearKeywords } from "@workspace/api-client-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Trash2, Plus, AlertCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function TextKeywords() {
  const { data, isLoading } = useGetKeywords();
  const { mutate: addKeyword, isPending: isAdding } = useSetKeyword();
  const { mutate: deleteKeyword, isPending: isDeleting } = useDeleteKeyword();
  const { mutate: clearKeywords, isPending: isClearing } = useClearKeywords();
  const queryClient = useQueryClient();

  const [newKey, setNewKey] = useState("");
  const [newReply, setNewReply] = useState("");

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKey || !newReply) return;
    addKeyword(
      { keyword: newKey, data: { reply: newReply } },
      {
        onSuccess: () => {
          setNewKey("");
          setNewReply("");
          queryClient.invalidateQueries({ queryKey: ["/api/keywords"] });
        }
      }
    );
  };

  const handleDelete = (key: string) => {
    deleteKeyword(
      { keyword: key },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/keywords"] }) }
    );
  };

  const handleClearAll = () => {
    if (confirm("ยืนยันการลบคีย์เวิร์ดทั้งหมด?")) {
      clearKeywords(undefined, {
        onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/keywords"] })
      });
    }
  };

  const keywordEntries = Object.entries(data?.keywords || {});

  return (
    <div className="pb-10">
      <PageHeader 
        title="คีย์เวิร์ดข้อความ (Auto Reply)" 
        description="ตั้งค่าให้บอทตอบกลับอัตโนมัติเมื่อพิมพ์คำที่กำหนด"
        action={
          <Button variant="destructive" onClick={handleClearAll} disabled={isClearing || keywordEntries.length === 0}>
            รีเซ็ททั้งหมด (Clear All)
          </Button>
        }
      />

      <Card className="mb-8 border-primary/20 bg-primary/5">
        <CardContent className="p-6">
          <form onSubmit={handleAdd} className="flex flex-col md:flex-row items-end gap-4">
            <div className="w-full md:w-1/3">
              <Label className="mb-2 block text-primary">คำที่พิมพ์ (Keyword)</Label>
              <Input 
                placeholder="เช่น: หวัดดี" 
                value={newKey}
                onChange={e => setNewKey(e.target.value)}
                className="bg-background border-primary/20 focus-visible:ring-primary/50"
              />
            </div>
            <div className="w-full md:flex-1">
              <Label className="mb-2 block text-primary">ข้อความตอบกลับ (Reply)</Label>
              <Input 
                placeholder="เช่น: สวัสดีจ้า มีอะไรให้ช่วยไหม" 
                value={newReply}
                onChange={e => setNewReply(e.target.value)}
                className="bg-background border-primary/20 focus-visible:ring-primary/50"
              />
            </div>
            <Button type="submit" disabled={!newKey || !newReply || isAdding} className="w-full md:w-auto">
              <Plus className="w-4 h-4 mr-2" /> เพิ่มคีย์เวิร์ด
            </Button>
          </form>
        </CardContent>
      </Card>

      <div className="space-y-3">
        {isLoading ? (
          <div className="text-center py-12 text-muted-foreground animate-pulse">กำลังโหลด...</div>
        ) : keywordEntries.length === 0 ? (
          <div className="text-center py-16 px-4 rounded-xl border border-dashed border-white/10 bg-white/5">
            <AlertCircle className="w-10 h-10 mx-auto text-muted-foreground mb-3 opacity-50" />
            <h3 className="text-lg font-medium text-foreground">ยังไม่มีคีย์เวิร์ด</h3>
            <p className="text-sm text-muted-foreground mt-1">เพิ่มคีย์เวิร์ดด้านบนเพื่อให้บอทเริ่มตอบกลับอัตโนมัติ</p>
          </div>
        ) : (
          <AnimatePresence>
            {keywordEntries.map(([key, reply]) => (
              <motion.div
                key={key}
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: "auto" }}
                exit={{ opacity: 0, height: 0 }}
                transition={{ duration: 0.2 }}
              >
                <Card className="hover:bg-white/5 transition-colors overflow-hidden group">
                  <CardContent className="p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge variant="outline" className="text-xs bg-black/20">Trigger</Badge>
                        <span className="font-bold text-lg text-primary truncate">{key}</span>
                      </div>
                      <p className="text-sm text-muted-foreground truncate pl-1 border-l-2 border-primary/30 ml-1">
                        {reply}
                      </p>
                    </div>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      onClick={() => handleDelete(key)}
                      disabled={isDeleting}
                      className="text-muted-foreground hover:text-destructive hover:bg-destructive/10 shrink-0"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        )}
      </div>
    </div>
  );
}
