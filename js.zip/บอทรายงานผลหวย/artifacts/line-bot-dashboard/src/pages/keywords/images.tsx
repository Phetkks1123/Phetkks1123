import { PageHeader } from "@/components/page-header";
import { Card, CardContent, Button, Input, Label, Badge } from "@/components/ui/core";
import { useGetImageKeywords, useSetImageKeyword, useDeleteImageKeyword, useClearImageKeywords } from "@workspace/api-client-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Trash2, Plus, Image as ImageIcon } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function ImageKeywords() {
  const { data, isLoading } = useGetImageKeywords();
  const { mutate: addKeyword, isPending: isAdding } = useSetImageKeyword();
  const { mutate: deleteKeyword, isPending: isDeleting } = useDeleteImageKeyword();
  const { mutate: clearKeywords, isPending: isClearing } = useClearImageKeywords();
  const queryClient = useQueryClient();

  const [newKey, setNewKey] = useState("");
  const [newPath, setNewPath] = useState("");

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newKey || !newPath) return;
    addKeyword(
      { keyword: newKey, data: { imagePath: newPath } },
      {
        onSuccess: () => {
          setNewKey("");
          setNewPath("");
          queryClient.invalidateQueries({ queryKey: ["/api/image-keywords"] });
        }
      }
    );
  };

  const handleDelete = (key: string) => {
    deleteKeyword(
      { keyword: key },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/image-keywords"] }) }
    );
  };

  const handleClearAll = () => {
    if (confirm("ยืนยันการลบคีย์เวิร์ดรูปภาพทั้งหมด?")) {
      clearKeywords(undefined, {
        onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/image-keywords"] })
      });
    }
  };

  const keywordEntries = Object.entries(data?.imageKeywords || {});

  return (
    <div className="pb-10">
      <PageHeader 
        title="คีย์เวิร์ดรูปภาพ" 
        description="เมื่อพิมพ์คีย์เวิร์ด บอทจะส่งรูปภาพกลับไป"
        action={
          <Button variant="destructive" onClick={handleClearAll} disabled={isClearing || keywordEntries.length === 0}>
            รีเซ็ททั้งหมด (Clear All)
          </Button>
        }
      />

      <Card className="mb-8 border-accent/20 bg-accent/5">
        <CardContent className="p-6">
          <form onSubmit={handleAdd} className="flex flex-col md:flex-row items-end gap-4">
            <div className="w-full md:w-1/3">
              <Label className="mb-2 block text-accent-foreground">คำที่พิมพ์ (Keyword)</Label>
              <Input 
                placeholder="เช่น: ขอดูรูปหน่อย" 
                value={newKey}
                onChange={e => setNewKey(e.target.value)}
                className="bg-background border-accent/20 focus-visible:ring-accent/50 focus-visible:border-accent"
              />
            </div>
            <div className="w-full md:flex-1">
              <Label className="mb-2 block text-accent-foreground">URL รูปภาพ (Image URL)</Label>
              <Input 
                placeholder="https://example.com/image.jpg" 
                value={newPath}
                onChange={e => setNewPath(e.target.value)}
                className="bg-background border-accent/20 focus-visible:ring-accent/50 focus-visible:border-accent"
              />
            </div>
            <Button type="submit" disabled={!newKey || !newPath || isAdding} className="w-full md:w-auto bg-accent text-white hover:bg-accent/80">
              <Plus className="w-4 h-4 mr-2" /> เพิ่มรููปภาพ
            </Button>
          </form>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {isLoading ? (
          <div className="col-span-full text-center py-12 text-muted-foreground animate-pulse">กำลังโหลด...</div>
        ) : keywordEntries.length === 0 ? (
          <div className="col-span-full text-center py-16 px-4 rounded-xl border border-dashed border-white/10 bg-white/5">
            <ImageIcon className="w-10 h-10 mx-auto text-muted-foreground mb-3 opacity-50" />
            <h3 className="text-lg font-medium text-foreground">ยังไม่มีคีย์เวิร์ดรูปภาพ</h3>
          </div>
        ) : (
          <AnimatePresence>
            {keywordEntries.map(([key, path]) => (
              <motion.div
                key={key}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.2 }}
              >
                <Card className="overflow-hidden group h-full flex flex-col">
                  <div className="aspect-video w-full bg-black/40 relative overflow-hidden">
                    <img 
                      src={path} 
                      alt={key} 
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = 'https://placehold.co/600x400/1a1a1a/333333?text=Invalid+Image+URL';
                      }}
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end justify-center pb-4">
                      <Button variant="destructive" size="sm" onClick={() => handleDelete(key)} disabled={isDeleting}>
                        <Trash2 className="w-4 h-4 mr-2" /> ลบรูปนี้
                      </Button>
                    </div>
                  </div>
                  <CardContent className="p-4 flex-1">
                    <Badge variant="secondary" className="mb-2">Keyword</Badge>
                    <h4 className="font-bold text-lg text-foreground truncate" title={key}>{key}</h4>
                    <p className="text-xs text-muted-foreground mt-2 truncate opacity-50" title={path}>{path}</p>
                  </CardContent>
                </Card>
              </motion.div>
            ))}
          </AnimatePresence>
        )}
      </div>
    </div>
  );
}
