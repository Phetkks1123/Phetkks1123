import { PageHeader } from "@/components/page-header";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, Switch, Badge, Button } from "@/components/ui/core";
import { useGetSettings, useUpdateSettings, useGetBlacklist, useGetKeywords } from "@workspace/api-client-react";
import { Activity, Users, MessageSquare, Shield, ArrowRight } from "lucide-react";
import { Link } from "wouter";
import { motion } from "framer-motion";

export default function Dashboard() {
  const { data: settings, isLoading: loadingSettings } = useGetSettings();
  const { data: blacklist, isLoading: loadingBlacklist } = useGetBlacklist();
  const { data: keywords, isLoading: loadingKeywords } = useGetKeywords();
  const { mutate: updateSettings } = useUpdateSettings();

  const toggleSetting = (key: keyof typeof settings, value: boolean) => {
    updateSettings({ data: { [key]: value } });
  };

  const stats = [
    { name: "Blacklisted Users", value: blacklist?.blacklist.length || 0, icon: Shield, color: "text-destructive" },
    { name: "Auto Keywords", value: Object.keys(keywords?.keywords || {}).length, icon: MessageSquare, color: "text-primary" },
    { name: "Bot Status", value: "Online", icon: Activity, color: "text-primary" },
    { name: "Monitored Groups", value: "Active", icon: Users, color: "text-accent-foreground" },
  ];

  return (
    <div className="space-y-8 pb-10">
      {/* Hero Section */}
      <div className="relative rounded-3xl overflow-hidden border border-white/10 bg-card">
        <div className="absolute inset-0">
          <img 
            src={`${import.meta.env.BASE_URL}images/hero-mesh.png`} 
            alt="Hero Background" 
            className="w-full h-full object-cover opacity-40 mix-blend-screen"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent" />
        </div>
        
        <div className="relative z-10 p-8 md:p-12 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <Badge variant="outline" className="mb-4 bg-primary/10 text-primary border-primary/20 backdrop-blur-md">
              System Online
            </Badge>
            <h1 className="text-3xl md:text-5xl font-bold text-white mb-4">
              Dashboard Overview
            </h1>
            <p className="text-muted-foreground max-w-xl text-lg">
              Manage your LINE bot automation, monitor statistics, and configure protection settings in real-time.
            </p>
          </div>
          <Link href="/auto">
            <Button size="lg" className="rounded-full shadow-primary/25">
              Quick Settings <ArrowRight className="ml-2 w-4 h-4" />
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat, i) => (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            key={stat.name}
          >
            <Card className="hover:border-primary/30 transition-colors">
              <CardContent className="p-6 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-muted-foreground mb-1">{stat.name}</p>
                  <h3 className="text-2xl font-bold text-foreground">
                    {loadingSettings || loadingBlacklist || loadingKeywords ? "-" : stat.value}
                  </h3>
                </div>
                <div className={`p-3 rounded-xl bg-white/5 ${stat.color}`}>
                  <stat.icon className="w-6 h-6" />
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      {/* Quick Toggles */}
      <div>
        <h2 className="text-xl font-bold mb-4 flex items-center gap-2">
          <Activity className="w-5 h-5 text-primary" /> Active Protections
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {loadingSettings ? null : (
            <>
              <ToggleCard 
                title="Auto Block" 
                description="Automatically block specific users/patterns"
                checked={settings?.auto_block}
                onChange={(c) => toggleSetting('auto_block', c)}
              />
              <ToggleCard 
                title="Auto Read" 
                description="Mark all incoming messages as read"
                checked={settings?.auto_read}
                onChange={(c) => toggleSetting('auto_read', c)}
              />
              <ToggleCard 
                title="Auto Join" 
                description="Automatically accept group invites"
                checked={settings?.auto_join}
                onChange={(c) => toggleSetting('auto_join', c)}
              />
            </>
          )}
        </div>
      </div>
    </div>
  );
}

function ToggleCard({ title, description, checked, onChange }: { title: string, description: string, checked?: boolean, onChange: (c: boolean) => void }) {
  return (
    <Card className={`transition-all duration-300 ${checked ? 'border-primary/50 shadow-[0_0_15px_rgba(6,199,85,0.1)]' : ''}`}>
      <CardContent className="p-6 flex items-center justify-between gap-4">
        <div>
          <h4 className="font-semibold text-foreground">{title}</h4>
          <p className="text-xs text-muted-foreground mt-1 line-clamp-1">{description}</p>
        </div>
        <Switch checked={checked} onCheckedChange={onChange} />
      </CardContent>
    </Card>
  );
}
