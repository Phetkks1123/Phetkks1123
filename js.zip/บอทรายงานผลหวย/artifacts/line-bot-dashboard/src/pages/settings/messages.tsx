import { PageHeader } from "@/components/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, Button, Textarea } from "@/components/ui/core";
import { useGetSettings, useSetAddMessage, useSetMentionMessage, useSetWelcomeMessage } from "@workspace/api-client-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";

const schema = z.object({
  add_message: z.string().min(1, "กรุณากรอกข้อความ"),
  mention_message: z.string().min(1, "กรุณากรอกข้อความ"),
  welcome_message: z.string().min(1, "กรุณากรอกข้อความ"),
});

type FormValues = z.infer<typeof schema>;

export default function MessagesSettings() {
  const { data: settings, isLoading } = useGetSettings();
  const { mutate: setAdd, isPending: isAdding } = useSetAddMessage();
  const { mutate: setMention, isPending: isMentioning } = useSetMentionMessage();
  const { mutate: setWelcome, isPending: isWelcoming } = useSetWelcomeMessage();
  const queryClient = useQueryClient();

  const form = useForm<FormValues>({
    resolver: zodResolver(schema),
    defaultValues: {
      add_message: "",
      mention_message: "",
      welcome_message: "",
    }
  });

  useEffect(() => {
    if (settings) {
      form.reset({
        add_message: settings.add_message || "",
        mention_message: settings.mention_message || "",
        welcome_message: settings.welcome_message || "",
      });
    }
  }, [settings, form]);

  const onSaveAdd = () => {
    setAdd({ data: { message: form.getValues("add_message") } }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/settings"] })
    });
  };

  const onSaveMention = () => {
    setMention({ data: { message: form.getValues("mention_message") } }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/settings"] })
    });
  };

  const onSaveWelcome = () => {
    setWelcome({ data: { message: form.getValues("welcome_message") } }, {
      onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/settings"] })
    });
  };

  return (
    <div className="pb-10 max-w-4xl">
      <PageHeader 
        title="ข้อความต้อนรับ & แท็ก" 
        description="ตั้งค่าข้อความที่จะให้บอทตอบกลับในสถานการณ์ต่างๆ"
      />

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>ข้อความต้อนรับสมาชิกใหม่ (Welcome Message)</CardTitle>
            <CardDescription>
              ข้อความนี้จะถูกส่งไปยังกลุ่มอัตโนมัติเมื่อมีสมาชิกใหม่เข้าร่วม (ต้องเปิดฟังก์ชัน "ต้อนรับสมาชิกใหม่" ในตั้งค่าระบบออโต้)
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              {...form.register("welcome_message")}
              placeholder="ยินดีต้อนรับเข้าสู่กลุ่มนะคะ &#10;ขอให้สนุกกับการพูดคุยนะคะ!"
              className="min-h-[120px] bg-black/20"
            />
            <Button onClick={onSaveWelcome} isLoading={isWelcoming}>
              บันทึกข้อความต้อนรับกลุ่ม
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>ข้อความเมื่อมีคนแอด (Add Message)</CardTitle>
            <CardDescription>
              ข้อความนี้จะถูกส่งไปอัตโนมัติเมื่อมีคนแอดบอทเป็นเพื่อน (ต้องเปิดฟังก์ชัน "แจ้งเตือนคนแอด" ในตั้งค่าระบบออโต้)
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea 
              {...form.register("add_message")}
              placeholder="ยินดีต้อนรับสู่ LINE Bot ของเรา..."
              className="min-h-[120px] bg-black/20"
            />
            <Button onClick={onSaveAdd} isLoading={isAdding} variant="secondary">
              บันทึกข้อความคนแอด
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>ข้อความเมื่อถูกแท็ก (Mention Message)</CardTitle>
            <CardDescription>
              ข้อความนี้จะถูกส่งไปอัตโนมัติเมื่อมีคนพิมพ์ @แท็กชื่อบอท ในกลุ่ม (ต้องเปิดฟังก์ชัน "แจ้งเตือนคนแทค")
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea 
              {...form.register("mention_message")}
              placeholder="เรียกเราหรอ มีอะไรให้ช่วยไหม..."
              className="min-h-[120px] bg-black/20"
            />
            <Button onClick={onSaveMention} isLoading={isMentioning} variant="secondary">
              บันทึกข้อความคนแท็ก
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
