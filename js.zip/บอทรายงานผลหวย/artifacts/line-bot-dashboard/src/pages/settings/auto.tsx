import { PageHeader } from "@/components/page-header";
import { Card, CardContent, Label, Switch } from "@/components/ui/core";
import { useGetSettings, useUpdateSettings } from "@workspace/api-client-react";
import { Shield, Zap, MessageCircle, UserPlus, LogOut, Ticket, Users } from "lucide-react";
import { motion } from "framer-motion";
import { useQueryClient } from "@tanstack/react-query";

const settingConfigs = [
  { id: "auto_block", label: "บล็อคอัตโนมัติ (Auto Block)", desc: "บล็อคคนที่แอดมาหรือคนที่อยู่ใน Blacklist อัตโนมัติ", icon: Shield },
  { id: "auto_read", label: "อ่านแชทอัตโนมัติ (Auto Read)", desc: "ติ๊กอ่านข้อความที่เข้ามาทั้งหมดโดยอัตโนมัติ", icon: Zap },
  { id: "auto_join", label: "เข้ากลุ่มอัตโนมัติ (Auto Join)", desc: "กดยอมรับคำเชิญเข้ากลุ่มโดยอัตโนมัติ", icon: UserPlus },
  { id: "auto_jointicket", label: "มุดลิ้งกลุ่มอัตโนมัติ (Auto Join Ticket)", desc: "เข้ากลุ่มผ่านลิ้งก์ที่ถูกส่งมาโดยอัตโนมัติ", icon: Ticket },
  { id: "auto_leave", label: "ออกแชทรวมอัตโนมัติ (Auto Leave)", desc: "ออกจากแชทรวม (แชทที่ไม่ใช่กลุ่ม) โดยอัตโนมัติ", icon: LogOut },
  { id: "auto_add", label: "แจ้งเตือนคนแอด (Auto Add)", desc: "ส่งข้อความต้อนรับเมื่อมีคนแอดบอทเป็นเพื่อน", icon: MessageCircle },
  { id: "auto_mention", label: "แจ้งเตือนคนแทค (Auto Mention)", desc: "ตอบกลับอัตโนมัติเมื่อมีคนแท็ก (@mention) บอท", icon: MessageCircle },
  { id: "auto_welcome", label: "ต้อนรับสมาชิกใหม่ (Auto Welcome)", desc: "ส่งข้อความต้อนรับอัตโนมัติเมื่อมีสมาชิกใหม่เข้ากลุ่ม", icon: Users },
] as const;

export default function AutoSettings() {
  const { data: settings, isLoading } = useGetSettings();
  const { mutate: updateSettings } = useUpdateSettings();
  const queryClient = useQueryClient();

  const handleToggle = (id: keyof typeof settings, checked: boolean) => {
    updateSettings(
      { data: { [id]: checked } },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
        }
      }
    );
  };

  return (
    <div className="pb-10">
      <PageHeader 
        title="ตั้งค่าระบบออโต้" 
        description="เปิด/ปิดการทำงานอัตโนมัติต่างๆ ของบอท"
      />

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {settingConfigs.map((config, i) => {
          const isChecked = settings ? settings[config.id as keyof typeof settings] as boolean : false;
          
          return (
            <motion.div
              key={config.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <Card className={`h-full transition-all duration-300 ${isChecked ? 'bg-primary/5 border-primary/30' : ''}`}>
                <CardContent className="p-6">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex gap-4">
                      <div className={`mt-1 p-2 rounded-lg ${isChecked ? 'bg-primary/20 text-primary' : 'bg-white/5 text-muted-foreground'}`}>
                        <config.icon className="w-5 h-5" />
                      </div>
                      <div>
                        <Label htmlFor={config.id} className="text-base font-semibold cursor-pointer block mb-1">
                          {config.label}
                        </Label>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {config.desc}
                        </p>
                      </div>
                    </div>
                    <div className="mt-1">
                      <Switch 
                        id={config.id}
                        disabled={isLoading}
                        checked={isChecked}
                        onCheckedChange={(c) => handleToggle(config.id as keyof typeof settings, c)}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
