import { PageHeader } from "@/components/page-header";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/core";
import { useGetHelpMessages } from "@workspace/api-client-react";
import { TerminalSquare, BookOpen } from "lucide-react";
import { motion } from "framer-motion";

export default function HelpCommands() {
  const { data, isLoading } = useGetHelpMessages();

  const sections = data ? [
    { title: "คำสั่งทั่วไป (Main)", content: data.main },
    { title: "คำสั่งโปรไฟล์ (Profile)", content: data.profile },
    { title: "คำสั่งกลุ่ม (Group)", content: data.group },
    { title: "คำสั่งเครื่องมือ (Tools)", content: data.tools },
    { title: "คำสั่งการตั้งค่า (Settings)", content: data.settings },
  ] : [];

  return (
    <div className="pb-10">
      <PageHeader 
        title="คู่มือคำสั่งบอท" 
        description="รวมคำสั่งทั้งหมดที่บอทรองรับ สามารถพิมพ์คำสั่งเหล่านี้ในแชท LINE ได้โดยตรง"
      />

      {isLoading ? (
        <div className="grid gap-6 animate-pulse">
          {[1,2,3].map(i => (
            <div key={i} className="h-48 bg-card rounded-xl border border-white/5" />
          ))}
        </div>
      ) : (
        <div className="grid gap-6 lg:grid-cols-2">
          {sections.map((section, i) => (
            <motion.div
              key={section.title}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className="h-full bg-card/40 backdrop-blur-md">
                <CardHeader className="pb-3 border-b border-white/5 bg-white/5">
                  <CardTitle className="text-lg flex items-center gap-2 text-primary">
                    <TerminalSquare className="w-5 h-5" />
                    {section.title}
                  </CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="p-6 font-mono text-sm leading-relaxed text-muted-foreground whitespace-pre-wrap bg-black/20 rounded-b-xl overflow-x-auto">
                    {section.content || "ไม่มีข้อมูลในหมวดหมู่นี้"}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: sections.length * 0.1 }}
            className="lg:col-span-2"
          >
            <Card className="border-primary/20 bg-primary/5 mt-4">
              <CardContent className="p-6 flex items-start gap-4">
                <div className="p-3 rounded-full bg-primary/20 text-primary shrink-0">
                  <BookOpen className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-semibold text-lg text-primary mb-1">ข้อแนะนำการใช้งาน</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    คำสั่งที่มีวงเล็บ เช่น <code className="text-primary bg-primary/10 px-1 rounded">@!</code> 
                    หมายถึงการแท็กชื่อผู้ใช้ คำสั่งบางคำสั่งสามารถใช้ได้เฉพาะในกลุ่มเท่านั้น โปรดตรวจสอบการอนุญาตและเปิดการตั้งค่า Auto ให้เหมาะสมในหน้าตั้งค่าระบบออโต้
                  </p>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      )}
    </div>
  );
}
