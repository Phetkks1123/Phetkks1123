import { PageHeader } from "@/components/page-header";
import { Card, CardContent, Button, Input, Label } from "@/components/ui/core";
import { useGetBlacklist, useAddToBlacklist, useRemoveFromBlacklist, useClearBlacklist } from "@workspace/api-client-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Trash2, UserX, ShieldAlert } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

export default function Blacklist() {
  const { data, isLoading } = useGetBlacklist();
  const { mutate: addBlock, isPending: isAdding } = useAddToBlacklist();
  const { mutate: removeBlock, isPending: isRemoving } = useRemoveFromBlacklist();
  const { mutate: clearBlock, isPending: isClearing } = useClearBlacklist();
  const queryClient = useQueryClient();

  const [newMid, setNewMid] = useState("");

  const handleAdd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMid) return;
    addBlock(
      { mid: newMid },
      {
        onSuccess: () => {
          setNewMid("");
          queryClient.invalidateQueries({ queryKey: ["/api/blacklist"] });
        }
      }
    );
  };

  const handleRemove = (mid: string) => {
    removeBlock(
      { mid },
      { onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/blacklist"] }) }
    );
  };

  const handleClearAll = () => {
    if (confirm("ยืนยันการล้างบัญชีดำทั้งหมด? ผู้ใช้ทั้งหมดจะถูกปลดบล็อค")) {
      clearBlock(undefined, {
        onSuccess: () => queryClient.invalidateQueries({ queryKey: ["/api/blacklist"] })
      });
    }
  };

  const list = data?.blacklist || [];

  return (
    <div className="pb-10 max-w-4xl">
      <PageHeader 
        title="บัญชีดำ (Blacklist)" 
        description="จัดการรายชื่อผู้ใช้ที่ถูกแบนหรือบล็อคไม่ให้ใช้งานบอท"
        action={
          <Button variant="destructive" onClick={handleClearAll} disabled={isClearing || list.length === 0}>
            ล้างบัญชีดำ (Clear All)
          </Button>
        }
      />

      <Card className="mb-8 border-destructive/20 bg-destructive/5">
        <CardContent className="p-6">
          <form onSubmit={handleAdd} className="flex flex-col md:flex-row items-end gap-4">
            <div className="w-full md:flex-1">
              <Label className="mb-2 block text-destructive">MID ผู้ใช้ (LINE User ID)</Label>
              <Input 
                placeholder="U1234567890abcdef..." 
                value={newMid}
                onChange={e => setNewMid(e.target.value)}
                className="bg-background border-destructive/20 focus-visible:ring-destructive/50 focus-visible:border-destructive font-mono text-sm"
              />
            </div>
            <Button type="submit" disabled={!newMid || isAdding} className="w-full md:w-auto bg-destructive text-white hover:bg-destructive/90 shadow-destructive/20">
              <UserX className="w-4 h-4 mr-2" /> ยัดดำ (Add to Blacklist)
            </Button>
          </form>
        </CardContent>
      </Card>

      <div className="space-y-2">
        {isLoading ? (
          <div className="text-center py-12 text-muted-foreground animate-pulse">กำลังโหลดข้อมูลบัญชีดำ...</div>
        ) : list.length === 0 ? (
          <div className="text-center py-16 px-4 rounded-xl border border-dashed border-white/10 bg-white/5">
            <ShieldAlert className="w-12 h-12 mx-auto text-muted-foreground mb-3 opacity-30" />
            <h3 className="text-lg font-medium text-foreground">ไม่พบรายชื่อบัญชีดำ</h3>
            <p className="text-sm text-muted-foreground mt-1">ยังไม่มีผู้ใช้ที่ถูกแบนในขณะนี้</p>
          </div>
        ) : (
          <div className="bg-card border border-white/5 rounded-xl overflow-hidden shadow-sm">
            <div className="grid grid-cols-[1fr_auto] gap-4 p-4 border-b border-white/5 bg-white/5 font-medium text-sm text-muted-foreground">
              <div>LINE MID</div>
              <div>การกระทำ</div>
            </div>
            <AnimatePresence>
              {list.map((mid) => (
                <motion.div
                  key={mid}
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: "auto" }}
                  exit={{ opacity: 0, height: 0 }}
                  className="grid grid-cols-[1fr_auto] gap-4 p-4 items-center border-b border-white/5 last:border-0 hover:bg-white/[0.02] transition-colors"
                >
                  <div className="font-mono text-sm text-foreground truncate" title={mid}>
                    {mid}
                  </div>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    onClick={() => handleRemove(mid)}
                    disabled={isRemoving}
                    className="border-white/10 hover:bg-white/10"
                  >
                    ปลดดำ (Remove)
                  </Button>
                </motion.div>
              ))}
            </AnimatePresence>
          </div>
        )}
      </div>
    </div>
  );
}
