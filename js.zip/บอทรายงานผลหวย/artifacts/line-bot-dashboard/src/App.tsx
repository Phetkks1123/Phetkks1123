import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import { Layout } from "@/components/layout";

// Pages
import Dashboard from "@/pages/dashboard";
import AutoSettings from "@/pages/settings/auto";
import MessagesSettings from "@/pages/settings/messages";
import TextKeywords from "@/pages/keywords/text";
import ImageKeywords from "@/pages/keywords/images";
import Blacklist from "@/pages/users/blacklist";
import HelpCommands from "@/pages/help";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: false,
      refetchOnWindowFocus: false,
    },
  },
});

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Dashboard} />
        <Route path="/auto" component={AutoSettings} />
        <Route path="/messages" component={MessagesSettings} />
        <Route path="/keywords/text" component={TextKeywords} />
        <Route path="/keywords/image" component={ImageKeywords} />
        <Route path="/blacklist" component={Blacklist} />
        <Route path="/help" component={HelpCommands} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
          <Router />
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
