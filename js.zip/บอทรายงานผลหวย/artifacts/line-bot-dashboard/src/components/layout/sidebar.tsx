import { Link, useLocation } from "wouter";
import { 
  LayoutDashboard, 
  Settings2, 
  MessageSquareText, 
  Type, 
  Image as ImageIcon, 
  ShieldBan, 
  TerminalSquare,
  Bot
} from "lucide-react";
import { cn } from "@/lib/utils";

const navigation = [
  { name: "แดชบอร์ด", href: "/", icon: LayoutDashboard },
  { name: "ตั้งค่าระบบออโต้", href: "/auto", icon: Settings2 },
  { name: "ข้อความต้อนรับ & แท็ก", href: "/messages", icon: MessageSquareText },
  { name: "คีย์เวิร์ดข้อความ", href: "/keywords/text", icon: Type },
  { name: "คีย์เวิร์ดรูปภาพ", href: "/keywords/image", icon: ImageIcon },
  { name: "บัญชีดำ (Blacklist)", href: "/blacklist", icon: ShieldBan },
  { name: "คู่มือคำสั่ง", href: "/help", icon: TerminalSquare },
];

export function Sidebar() {
  const [location] = useLocation();

  return (
    <aside className="w-72 hidden md:flex flex-col border-r border-white/5 bg-background/80 backdrop-blur-xl relative z-20">
      {/* Logo Area */}
      <div className="h-20 flex items-center px-8 border-b border-white/5 gap-3">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-primary/80 to-primary flex items-center justify-center shadow-lg shadow-primary/20">
          <Bot className="w-6 h-6 text-primary-foreground" />
        </div>
        <div>
          <h1 className="font-bold text-lg leading-tight tracking-wide text-foreground">LINE Bot</h1>
          <p className="text-xs text-primary/80 font-medium">Control Panel v2.0</p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 overflow-y-auto py-6 px-4 space-y-1">
        <div className="px-4 pb-2 mb-2">
          <p className="text-xs font-semibold text-muted-foreground tracking-wider uppercase">Menu</p>
        </div>
        {navigation.map((item) => {
          const isActive = location === item.href;
          return (
            <Link key={item.name} href={item.href}>
              <div
                className={cn(
                  "group flex items-center px-4 py-3 rounded-xl text-sm font-medium transition-all duration-200 cursor-pointer relative overflow-hidden",
                  isActive
                    ? "text-primary-foreground bg-primary/10"
                    : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                )}
              >
                {isActive && (
                  <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary rounded-r-full" />
                )}
                <item.icon
                  className={cn(
                    "mr-3 h-5 w-5 transition-colors",
                    isActive ? "text-primary" : "text-muted-foreground group-hover:text-foreground"
                  )}
                />
                {item.name}
              </div>
            </Link>
          );
        })}
      </nav>

      {/* Footer Area */}
      <div className="p-6 border-t border-white/5">
        <div className="bg-gradient-to-br from-white/5 to-white/0 rounded-xl p-4 border border-white/5">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-2 h-2 rounded-full bg-primary animate-pulse" />
            <span className="text-sm font-medium text-foreground">Status: Online</span>
          </div>
          <p className="text-xs text-muted-foreground">All systems operational and monitoring chats.</p>
        </div>
      </div>
    </aside>
  );
}
