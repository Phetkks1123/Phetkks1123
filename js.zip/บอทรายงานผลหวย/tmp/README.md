# LINE Bot Dashboard

## Requirements
- Node.js 20+
- pnpm (`npm install -g pnpm`)
- PostgreSQL (set `DATABASE_URL` env var)

## Setup & Run

```bash
# 1. Install dependencies
pnpm install

# 2. Push database schema
pnpm --filter @workspace/db run push

# 3. Start API server (port 8080)
pnpm --filter @workspace/api-server run dev

# 4. Start frontend (port 24776) — open separate terminal
pnpm --filter @workspace/line-bot-dashboard run dev
```

## Environment Variables
Create a `.env` file in the root:
```
DATABASE_URL=postgresql://user:password@localhost:5432/linebot
```

## Features
- ตั้งค่าระบบออโต้ (Auto Block, Read, Join, Leave, Add, Mention, Welcome)
- ข้อความต้อนรับ & แท็ก (Add, Mention, Welcome messages)
- คีย์เวิร์ดตอบกลับข้อความ
- คีย์เวิร์ดตอบกลับรูปภาพ
- บัญชีดำ (Blacklist)
