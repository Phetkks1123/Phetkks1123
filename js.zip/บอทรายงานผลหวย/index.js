/**
 * LINE Bot รายงานผลหวยไทย + หวยยี่กี่ (โชคมา)
 * ติดตั้ง: npm install
 * รัน: node index.js
 *
 * ต้องตั้งค่า environment variables ก่อน:
 *   LINE_CHANNEL_SECRET=xxxxx
 *   LINE_CHANNEL_ACCESS_TOKEN=xxxxx
 *   YIKI_USERNAME=ชื่อผู้ใช้เว็บโชคมา
 *   YIKI_PASSWORD=รหัสผ่านเว็บโชคมา
 *   PORT=3000  (ไม่บังคับ, default 3000)
 *
 * หรือสร้างไฟล์ .env แล้วใช้:
 *   npm install dotenv
 *   node -r dotenv/config index.js
 */

const express = require("express");
const crypto = require("crypto");
const axios = require("axios");
const cheerio = require("cheerio");
const CryptoJS = require("crypto-js");

// ถ้ามีไฟล์ .env ให้โหลดอัตโนมัติ
try { require("dotenv").config(); } catch {}

const app = express();
const PORT = process.env.PORT || 3000;

const CHANNEL_SECRET = process.env.LINE_CHANNEL_SECRET || "";
const CHANNEL_ACCESS_TOKEN = process.env.LINE_CHANNEL_ACCESS_TOKEN || "";
const YIKI_USERNAME = process.env.YIKI_USERNAME || "";
const YIKI_PASSWORD = process.env.YIKI_PASSWORD || "";
const LINE_REPLY_API = "https://api.line.me/v2/bot/message/reply";

const FIREBASE_API_KEY = "AIzaSyCnakSgl1YrCuJWTGnMTVYvDvifcPXRnU8";
const FIRESTORE_BASE = "https://firestore.googleapis.com/v1/projects/alex-3fe40/databases/(default)/documents";
const USERDATA_KEY = "gQPC2yHHPb8Y9XKSv5qhqdBMAR6UQ3";

if (!CHANNEL_SECRET || !CHANNEL_ACCESS_TOKEN) {
  console.error("❌ กรุณาตั้งค่า LINE_CHANNEL_SECRET และ LINE_CHANNEL_ACCESS_TOKEN");
  process.exit(1);
}

// ---- Middleware ----
app.use(
  express.json({
    verify: (req, _res, buf) => {
      req.rawBody = buf;
    },
  })
);

// ---- Signature Verification ----
function verifySignature(rawBody, signature) {
  const hash = crypto
    .createHmac("SHA256", CHANNEL_SECRET)
    .update(rawBody)
    .digest("base64");
  return hash === signature;
}

// ---- Reply to LINE ----
async function replyMessages(replyToken, texts) {
  const messages = texts.slice(0, 5).map((text) => ({ type: "text", text }));
  try {
    await axios.post(
      LINE_REPLY_API,
      { replyToken, messages },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${CHANNEL_ACCESS_TOKEN}`,
        },
      }
    );
  } catch (err) {
    console.error("Reply error:", err.response?.data || err.message);
  }
}

// ============================================================
// ---- YIKI (ยี่กี่) Service ----
// ============================================================

let yikiTokenCache = null;

async function getUserByCredentials() {
  const res = await axios.post(
    `${FIRESTORE_BASE}:runQuery?key=${FIREBASE_API_KEY}`,
    {
      structuredQuery: {
        from: [{ collectionId: "users" }],
        where: {
          fieldFilter: {
            field: { fieldPath: "username" },
            op: "EQUAL",
            value: { stringValue: YIKI_USERNAME },
          },
        },
        limit: 1,
      },
    },
    {
      headers: {
        "Content-Type": "application/json",
        Referer: "https://xn--42cl4e4cwd.net/",
      },
      timeout: 10000,
    }
  );

  const docs = res.data;
  if (!docs || !docs[0] || !docs[0].document) return null;

  const fields = docs[0].document.fields;
  const storedPass = fields?.password?.stringValue;
  if (storedPass !== YIKI_PASSWORD) return null;

  const userId = docs[0].document.name.split("/").pop();
  return { userId, fields };
}

async function fetchYikiResults() {
  if (!YIKI_USERNAME || !YIKI_PASSWORD) {
    throw new Error("กรุณาตั้งค่า YIKI_USERNAME และ YIKI_PASSWORD");
  }

  const user = await getUserByCredentials();
  if (!user) {
    throw new Error("ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง");
  }

  // Try Firestore first - look for lotto results with type=yeekee
  try {
    const res = await axios.post(
      `${FIRESTORE_BASE}:runQuery?key=${FIREBASE_API_KEY}`,
      {
        structuredQuery: {
          from: [{ collectionId: "lotto", allDescendants: true }],
          where: {
            fieldFilter: {
              field: { fieldPath: "type" },
              op: "EQUAL",
              value: { stringValue: "yeekee" },
            },
          },
          orderBy: [{ field: { fieldPath: "createdate" }, direction: "DESCENDING" }],
          limit: 10,
        },
      },
      {
        headers: {
          "Content-Type": "application/json",
          Referer: "https://xn--42cl4e4cwd.net/",
        },
        timeout: 10000,
      }
    );

    const docs = res.data;
    if (docs && docs.length > 0 && docs[0].document) {
      return docs.filter((d) => d.document).map((d) => {
        const f = d.document.fields;
        return {
          round: f?.roundno?.integerValue || f?.round?.stringValue || "?",
          period: f?.period?.stringValue || f?.date?.stringValue || "?",
          twoTop: f?.num2top?.stringValue || f?.two_top?.stringValue || "??",
          twoBottom: f?.num2bottom?.stringValue || f?.two_bottom?.stringValue || "??",
          threeTop: f?.num3top?.stringValue || f?.three_top?.stringValue || "???",
        };
      });
    }
  } catch (err) {
    console.warn("Firestore query failed, trying web scrape:", err.message);
  }

  // Fallback: scrape the pingpong page
  return await fetchYikiFromPage();
}

async function fetchYikiFromPage() {
  const res = await axios.get("https://xn--42cl4e4cwd.net/member/pingpong", {
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
      Referer: "https://xn--42cl4e4cwd.net/",
    },
    timeout: 15000,
  });

  const $ = cheerio.load(res.data);
  const results = [];

  $("table tr").each((_, row) => {
    const cells = $(row).find("td");
    if (cells.length >= 3) {
      const round = $(cells[0]).text().trim();
      const period = $(cells[1]).text().trim();
      const twoTop = $(cells[2]).text().trim();
      const twoBottom = cells.length > 3 ? $(cells[3]).text().trim() : "??";
      const threeTop = cells.length > 4 ? $(cells[4]).text().trim() : "???";

      if (/^\d+$/.test(round)) {
        results.push({ round, period, twoTop, twoBottom, threeTop });
      }
    }
  });

  return results;
}

let yikiCache = null;
const YIKI_TTL = 3 * 60 * 1000; // 3 minutes

async function getCachedYiki() {
  if (yikiCache && Date.now() - yikiCache.cachedAt < YIKI_TTL) {
    return yikiCache.data;
  }
  const data = await fetchYikiResults();
  yikiCache = { data, cachedAt: Date.now() };
  return data;
}

function formatYikiMessage(results) {
  if (!results || results.length === 0) {
    return "❌ ยังไม่มีผลหวยยี่กี่ในขณะนี้";
  }

  const now = new Date().toLocaleString("th-TH", { timeZone: "Asia/Bangkok" });
  const lines = [];

  lines.push("🎱 ผลหวยยี่กี่ล่าสุด");
  lines.push("─────────────────────");

  const latest = results[0];
  lines.push(`📌 งวดที่ ${latest.round}`);
  if (latest.period) lines.push(`📅 ${latest.period}`);
  lines.push("");
  lines.push(`🔢 2 ตัวบน: ${latest.twoTop}`);
  lines.push(`🔢 2 ตัวล่าง: ${latest.twoBottom}`);
  if (latest.threeTop && latest.threeTop !== "???") {
    lines.push(`🔣 3 ตัวบน: ${latest.threeTop}`);
  }

  if (results.length > 1) {
    lines.push("");
    lines.push("📋 ผลย้อนหลัง:");
    for (const r of results.slice(1, 5)) {
      lines.push(`  งวด ${r.round}: 2บน=${r.twoTop} | 2ล่าง=${r.twoBottom}${r.threeTop && r.threeTop !== "???" ? ` | 3บน=${r.threeTop}` : ""}`);
    }
  }

  lines.push("─────────────────────");
  lines.push(`🕐 อัพเดต: ${now}`);

  return lines.join("\n");
}

// ============================================================
// ---- หวยรัฐบาล Service ----
// ============================================================

async function fetchLotteryResult() {
  const sources = [
    { url: "https://www.glo.or.th/service/result", parser: parseGLO },
    { url: "https://news.sanook.com/lotto/", parser: parseSanook },
  ];

  for (const source of sources) {
    try {
      const res = await axios.get(source.url, {
        headers: {
          "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0.0.0 Safari/537.36",
          "Accept-Language": "th-TH,th;q=0.9",
        },
        timeout: 15000,
      });
      const result = source.parser(res.data);
      if (result && result.firstPrize.length > 0) return result;
    } catch (err) {
      console.warn(`Failed ${source.url}:`, err.message);
    }
  }
  return null;
}

function parseGLO(html) {
  const $ = cheerio.load(html);
  const firstPrize = [], nearbyFirst = [], twoDigit = [], threeDigitFront = [], threeDigitBack = [], secondPrize = [], thirdPrize = [], fourthPrize = [], fifthPrize = [];
  const date = $(".result-header").text().trim() || $("h1, h2").first().text().trim();

  $("[class*='prize1'], [class*='first-prize'], .prize-1").each((_, el) => {
    const t = $(el).text().trim().replace(/\D/g, "");
    if (t.length >= 5) firstPrize.push(t);
  });
  $("[class*='near'], [class*='adjacent']").each((_, el) => {
    const t = $(el).text().trim().replace(/\D/g, "");
    if (t.length >= 5) nearbyFirst.push(t);
  });
  $("[class*='two-digit'], [class*='2digit']").each((_, el) => {
    const t = $(el).text().trim().replace(/\D/g, "");
    if (t.length === 2) twoDigit.push(t);
  });

  return { date, firstPrize, nearbyFirst, twoDigit, threeDigitFront, threeDigitBack, secondPrize, thirdPrize, fourthPrize, fifthPrize };
}

function parseSanook(html) {
  const $ = cheerio.load(html);
  const firstPrize = [], nearbyFirst = [], twoDigit = [], threeDigitFront = [], threeDigitBack = [], secondPrize = [], thirdPrize = [], fourthPrize = [], fifthPrize = [];
  const date = $(".lotto-date, .lottery-date, h1").first().text().trim();

  $(".lottery1st, .lotto1st, [data-prize='1'], .prize1").each((_, el) => {
    const t = $(el).text().trim().replace(/\D/g, "");
    if (t.length >= 5) firstPrize.push(t.slice(0, 7));
  });
  $(".lotto-near, .nearby, .near1st").each((_, el) => {
    const t = $(el).text().trim().replace(/\D/g, "");
    if (t.length >= 5) nearbyFirst.push(t.slice(0, 7));
  });
  $(".lotto-2digit, .two-digit, [data-prize='last2']").each((_, el) => {
    const t = $(el).text().trim().replace(/\D/g, "");
    if (t.length === 2) twoDigit.push(t);
  });

  return { date, firstPrize, nearbyFirst, twoDigit, threeDigitFront, threeDigitBack, secondPrize, thirdPrize, fourthPrize, fifthPrize };
}

function formatLotteryMessage(result) {
  const now = new Date().toLocaleString("th-TH", { timeZone: "Asia/Bangkok" });
  const lines = [];

  lines.push("🎰 ผลสลากกินแบ่งรัฐบาล");
  if (result.date) lines.push(`📅 ${result.date}`);
  lines.push("─────────────────────");

  if (result.firstPrize.length > 0) {
    lines.push("🏆 รางวัลที่ 1");
    lines.push(`   ${result.firstPrize.join(", ")}`);
  }
  if (result.nearbyFirst.length > 0) {
    lines.push("🎖️ รางวัลข้างเคียงที่ 1");
    lines.push(`   ${result.nearbyFirst.join(", ")}`);
  }
  if (result.twoDigit.length > 0) {
    lines.push("🔢 เลขท้าย 2 ตัว");
    lines.push(`   ${result.twoDigit.join(", ")}`);
  }
  if (result.threeDigitFront.length > 0) {
    lines.push("🔣 เลข 3 ตัวหน้า");
    lines.push(`   ${result.threeDigitFront.join(", ")}`);
  }
  if (result.threeDigitBack.length > 0) {
    lines.push("🔣 เลข 3 ตัวท้าย");
    lines.push(`   ${result.threeDigitBack.join(", ")}`);
  }
  if (result.secondPrize.length > 0) {
    lines.push("🥈 รางวัลที่ 2");
    lines.push(`   ${result.secondPrize.join(", ")}`);
  }

  lines.push("─────────────────────");
  lines.push(`🕐 ดึงข้อมูลเมื่อ: ${now}`);

  return lines.join("\n");
}

// ============================================================
// ---- Handle LINE Event ----
// ============================================================

async function handleEvent(event) {
  if (event.type !== "message" || event.message.type !== "text") return;

  const replyToken = event.replyToken;
  const userText = event.message.text.trim().toLowerCase();

  console.log(`[${new Date().toLocaleString("th-TH")}] "${event.message.text}"`);

  if (
    userText.includes("ยี่กี่") ||
    userText.includes("yiki") ||
    userText.includes("yeekee") ||
    userText.includes("pingpong") ||
    userText.includes("ปิงปอง")
  ) {
    try {
      const results = await getCachedYiki();
      await replyMessages(replyToken, [formatYikiMessage(results)]);
    } catch (err) {
      console.error("Yiki error:", err.message);
      await replyMessages(replyToken, [`❌ ดึงข้อมูลยี่กี่ไม่ได้: ${err.message}`]);
    }
  } else if (
    userText.includes("หวย") ||
    userText.includes("ผลหวย") ||
    userText.includes("ลอตเตอรี่") ||
    userText.includes("lottery") ||
    userText.includes("lotto") ||
    userText === "ผล"
  ) {
    try {
      const result = await fetchLotteryResult();
      if (result) {
        await replyMessages(replyToken, [formatLotteryMessage(result)]);
      } else {
        await replyMessages(replyToken, ["❌ ไม่สามารถดึงข้อมูลผลหวยได้ในขณะนี้"]);
      }
    } catch (err) {
      await replyMessages(replyToken, ["❌ เกิดข้อผิดพลาด กรุณาลองใหม่"]);
    }
  } else if (
    userText.includes("help") ||
    userText.includes("ช่วยเหลือ") ||
    userText.includes("วิธีใช้") ||
    userText === "?"
  ) {
    await replyMessages(replyToken, [getHelpMessage()]);
  } else {
    await replyMessages(replyToken, [
      '👋 สวัสดีครับ!\n• พิมพ์ "หวย" → ผลหวยรัฐบาล\n• พิมพ์ "ยี่กี่" → ผลหวยยี่กี่\n• พิมพ์ "ช่วยเหลือ" → ดูคำสั่งทั้งหมด',
    ]);
  }
}

function getHelpMessage() {
  return [
    "🤖 บอทหวย - วิธีใช้งาน",
    "─────────────────────",
    "📌 หวยรัฐบาล:",
    '• "หวย" / "ผลหวย" / "ลอตเตอรี่"',
    "",
    "📌 หวยยี่กี่ (โชคมา):",
    '• "ยี่กี่" / "หวยยี่กี่" / "yiki"',
    "",
    '• "ช่วยเหลือ" → เมนูนี้',
    "─────────────────────",
  ].join("\n");
}

// ---- Routes ----
app.get("/", (_req, res) => {
  res.json({ status: "LINE Bot กำลังทำงาน ✅", features: ["หวยรัฐบาล", "หวยยี่กี่"] });
});

app.post("/webhook", (req, res) => {
  const signature = req.headers["x-line-signature"];
  if (!signature) return res.status(400).json({ error: "Missing signature" });
  if (!req.rawBody) return res.status(400).json({ error: "Missing raw body" });
  if (!verifySignature(req.rawBody, signature)) return res.status(401).json({ error: "Invalid signature" });

  res.status(200).json({ status: "ok" });

  const events = req.body.events || [];
  for (const event of events) {
    handleEvent(event).catch((err) => console.error("Event error:", err));
  }
});

// ---- Start Server ----
app.listen(PORT, () => {
  console.log(`✅ LINE Bot เริ่มทำงานแล้วที่ port ${PORT}`);
  console.log(`📌 Webhook URL: http://your-domain.com:${PORT}/webhook`);
  console.log("─────────────────────────────────────────");
  console.log("ฟีเจอร์: หวยรัฐบาล + หวยยี่กี่ (โชคมา)");
  if (!YIKI_USERNAME) console.warn("⚠️  ไม่ได้ตั้ง YIKI_USERNAME - หวยยี่กี่จะไม่ทำงาน");
});
