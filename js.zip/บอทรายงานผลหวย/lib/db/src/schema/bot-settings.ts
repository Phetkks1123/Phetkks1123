import { pgTable, text, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const botSettingsTable = pgTable("bot_settings", {
  id: text("id").primaryKey().default("singleton"),
  auto_block: boolean("auto_block").notNull().default(false),
  auto_read: boolean("auto_read").notNull().default(false),
  auto_join: boolean("auto_join").notNull().default(false),
  auto_jointicket: boolean("auto_jointicket").notNull().default(false),
  auto_leave: boolean("auto_leave").notNull().default(false),
  auto_add: boolean("auto_add").notNull().default(false),
  auto_mention: boolean("auto_mention").notNull().default(false),
  auto_welcome: boolean("auto_welcome").notNull().default(false),
  add_message: text("add_message").notNull().default(""),
  mention_message: text("mention_message").notNull().default(""),
  welcome_message: text("welcome_message").notNull().default(""),
  blacklist: jsonb("blacklist").notNull().default([]),
  keywords: jsonb("keywords").notNull().default({}),
  image_keywords: jsonb("image_keywords").notNull().default({}),
});

export const insertBotSettingsSchema = createInsertSchema(botSettingsTable);
export type InsertBotSettings = z.infer<typeof insertBotSettingsSchema>;
export type BotSettings = typeof botSettingsTable.$inferSelect;
