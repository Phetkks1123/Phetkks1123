# LINE Bot ผลหวยไทย + หวยยี่กี่

บอท LINE สำหรับรายงานผลสลากกินแบ่งรัฐบาล และผลหวยยี่กี่จากเว็บโชคมา

---

## ความต้องการ

- Node.js 18+ (https://nodejs.org)
- LINE Official Account พร้อม Messaging API
- บัญชีผู้ใช้เว็บ โชคมา (สำหรับหวยยี่กี่)
- เครื่องที่มี Public IP หรือใช้ ngrok สำหรับทดสอบ

---

## วิธีติดตั้งและรัน

### 1. ติดตั้ง Dependencies

```bash
npm install
```

### 2. ตั้งค่า Environment Variables

```bash
cp .env.example .env
```

แก้ไขไฟล์ `.env`:

```env
LINE_CHANNEL_SECRET=xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
LINE_CHANNEL_ACCESS_TOKEN=xxxxxxxx...
YIKI_USERNAME=ชื่อผู้ใช้โชคมา
YIKI_PASSWORD=รหัสผ่านโชคมา
PORT=3000
```

### 3. รัน Bot

```bash
node index.js
```

---

## วิธีรันบน VPS (Linux)

### วิธีที่ 1: รันตรงๆ (ปิด terminal แล้วหยุด)

```bash
node index.js
```

### วิธีที่ 2: รันด้วย PM2 (แนะนำ — ค้างเปิดตลอด + auto-restart)

```bash
# ติดตั้ง PM2
npm install -g pm2

# รัน bot
pm2 start index.js --name "line-bot"

# ดู logs
pm2 logs line-bot

# ให้ start อัตโนมัติเมื่อ VPS reboot
pm2 startup
pm2 save
```

### วิธีที่ 3: รันด้วย screen (ง่ายที่สุด)

```bash
# สร้าง screen session
screen -S linebot

# รัน bot
node index.js

# กด Ctrl+A แล้ว D เพื่อ detach (bot ยังทำงานอยู่)

# กลับมาดู logs
screen -r linebot
```

### วิธีที่ 4: รันด้วย nohup

```bash
nohup node index.js > bot.log 2>&1 &
echo "Bot PID: $!"

# ดู logs
tail -f bot.log
```

---

## ตั้งค่า Webhook ใน LINE

1. เข้า [LINE Developers Console](https://developers.line.biz/)
2. เลือก Channel → **Messaging API**
3. **Webhook URL**: `https://your-server-ip-or-domain.com/webhook`
4. กด **Verify** → ควรขึ้น "Success"
5. เปิด **Use webhook** เป็น ON

> ถ้า VPS ไม่มี domain ให้ใช้ IP ตรงๆ เช่น `http://1.2.3.4:3000/webhook`
> 
> LINE ต้องการ HTTPS สำหรับ production — ใช้ nginx + Let's Encrypt หรือ Cloudflare Tunnel

### ตั้งค่า nginx (ถ้ามี domain)

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_cache_bypass $http_upgrade;
    }
}
```

---

## คำสั่งที่รองรับ

| พิมพ์ | ผลลัพธ์ |
|-------|---------|
| `หวย` / `ผลหวย` / `ลอตเตอรี่` | ผลสลากกินแบ่งรัฐบาล |
| `ยี่กี่` / `หวยยี่กี่` / `yiki` | ผลหวยยี่กี่ล่าสุด (โชคมา) |
| `ช่วยเหลือ` / `help` | แสดงคำสั่งทั้งหมด |

---

## โครงสร้างไฟล์

```
line-bot-lottery/
├── index.js          # ไฟล์หลัก
├── package.json      # dependencies
├── .env.example      # ตัวอย่างการตั้งค่า
└── README.md         # คู่มือนี้
```
